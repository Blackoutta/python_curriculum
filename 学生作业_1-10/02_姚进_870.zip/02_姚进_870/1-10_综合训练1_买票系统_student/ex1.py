yh_xm = input("请输入你的姓名：")
p_sy = 100 #剩余的票数量
p_jg = 20  #票的价格
print("{}：你好\n欢迎来到云阳购票网\n票剩余数量：{}".format(yh_xm,p_sy))

while True:
    try:
        yh_gm = int(input("请输入你要购买的张数："))
    except ValueError:
        print("输入有错，请输入一个正整数，阿拉伯数字")
        continue

    if yh_gm > p_sy:
        print("超过剩余数量，现在票剩余的张数是：{}".format(p_sy))
        continue

    elif yh_gm == 0:
        print("不能输入0")
        continue

    elif yh_gm < 1:
        print("输入有错，票的张数不能是负数，请输入正整数")
        continue



    else:
        qr = input("确认购买请输入：gm 并按回车键 。退出请输入：tc 并按回车键:  ")
        if qr == 'gm':
            print("购买成功，你要购买的票是：{}张。价格：{}".format(yh_gm,p_jg * yh_gm))
            p_sy - yh_gm
            break


        elif qr == 'tc':
            print("已经退出完成")
            break
        else:
            print("输入有错")
