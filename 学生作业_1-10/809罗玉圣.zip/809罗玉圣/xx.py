ychx=100
wbsys=100
price=35
import os
while True:
 my_name = input("请输入你的姓名:")
 print("欢迎你:", my_name,"进入影院！")
 print("影院有如下电影，请你回复序号选择你想看的电影:")
 print("1.一出好戏   2.我不是药神")
 try:
  dy_name = int(input("请选择序号:"))
  if dy_name != 1 or dy_name !=2:
     raise ValueError  # 就引发一个 值错误，这个值错误会被下面的 except截取到
 except ValueError:
    print("错误：请输入序号！")
 else:
  if dy_name == 1:
   print("*********电影:一出好戏*********价格:{}元*********剩余票数:{}张".format(price, ychx))
   num = int(input("你需要购买几张票:"))
   if num<=ychx:
      s=price*num
      print("你购买的电影是:一出好戏,数量是:{}张,价格是:{}元".format(num,s))
      jg = int(input("请输入支付价格:"))
      if jg == s:
          print("支付成功")
          ychx=ychx-num
      else:
          print("支付失败")
   else :
          print("票数不足！")
   def clear_screen():  # 这个函数一旦被调用会对控制台进行清屏
    os.system('cls')


  elif dy_name == 2:
   print("*********电影:我不是药神*********价格:{}元*********剩余票数:{}张".format(price, wbsys))
   num = int(input("你需要购买几张票:"))
   if num<=wbsys:
      s=price*num
      print("你购买的电影是:我不是药神,数量是:{}张,价格是:{}元".format(num,s))
      jg = int(input("请输入支付价格:"))
      if jg == s:
        print("支付成功")
        wbsys=wbsys-num
      else:
        print("支付失败")
   else :
        print("票数不足！")
def clear_screen():  # 这个函数一旦被调用会对控制台进行清屏
 os.system('cls')
