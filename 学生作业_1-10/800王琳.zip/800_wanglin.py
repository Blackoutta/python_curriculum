import os
import random

def clear_screen():
    os.system('cls')

tickets = 500
tickets_price = 80

user_name = input("请输入您的名字：")
print("欢迎进入欢乐世界购票系统，{}".format(user_name))

while tickets != 0:
    print("当前剩余票数：{}".format(tickets))
    try:
        tickets_buy = int(input("请输入购买票数："))
        if tickets_buy <= 0:
            clear_screen()
            print("请输入一个大于0的整数！")
            continue
        elif tickets_buy <= tickets:
            clear_screen()
            print("您将购买{}张票，总票价为{}！".format(tickets_buy,tickets_price*tickets_buy))
            confirm = input("确认购买请输入CONFIRM并按回车，取消请输入任意字符并按回车！")
            if confirm.upper() == 'CONFIRM':
                print("购买成功！")
                tickets -= tickets_buy
                Y_N = input("是否继续购票？Y/N")
                if Y_N.upper() == 'Y':
                    continue
                elif Y_N.upper() == "N":
                    print("你已取消购票，欢迎下次光临！")
                    break
                else:
                    print("输入有误，正在退出……")
                    print("请重新登录！")
            else:
                print("正在为您取消订单……")
                print("订单取消完成！")
                break
        elif tickets_buy > tickets:
            clear_screen()
            print("您正在购买{}张票，剩余票数{}，剩余票数不足！请重新输入购买票数！".format(tickets_buy,tickets))
            continue
    except ValueError:
            print("请输入一个整数！")
else:
    clear_screen()
    print("对不起，今天的票已购完，请明天再来！")
